export interface ContractTemplate {
  id: string;
  name: string;
  description: string;
  language: "uz" | "ru";
  type: "service" | "sale" | "rent" | "custom";
  content: string;
}

export const contractTemplates: ContractTemplate[] = [
  {
    id: "service-uz",
    name: "Xizmat ko'rsatish shartnomasi",
    description: "Xizmat ko'rsatish bo'yicha standart shartnoma",
    language: "uz",
    type: "service",
    content: `XIZMAT KO'RSATISH SHARTNOMASI

Ushbu shartnoma {{date}} yili {{ourName}} (quyida "Xizmat ko'rsatuvchi" deb ataladi) va {{counterpartyName}} (quyida "Xizmat iste'molchi" deb ataladi) o'rtasida tuzildi.

1. SHARTNOMANING PREDMETI

1.1. Xizmat ko'rsatuvchi {{description}} xizmatlarini ko'rsatishga va'da beradi.

2. HAQLAR VA TO'LOV SHARTLARI

2.1. Xizmat iste'molchi {{amount}} {{currency}} miqdorda to'lov qiladi.
2.2. To'lov {{startDate}} sanasida amalga oshiriladi.

3. SHARTNOMANING MUDDATI

3.1. Ushbu shartnoma {{startDate}} sanasidan {{endDate}} sanasigacha amal qiladi.

4. TOMONLARNING MAJBURIYATLARI

4.1. Xizmat ko'rsatuvchi:
- Shartnomada belgilangan xizmatlarni sifatli va o'z vaqtida ko'rsatadi;
- Qonun va boshqa normativ hujjatlarga rioya qiladi.

4.2. Xizmat iste'molchi:
- To'lovlarni o'z vaqtida amalga oshiradi;
- Ko'rsatilayotgan xizmatlardan foydalanish qoidalariga rioya qiladi.

5. JAVOBGARLIK

5.1. Tomonlar shartnomaning shartlarini buzganligi uchun qonun hujjatlarida belgilangan javobgarlikka tortiladi.

6. SHARTNOMANING YAKUNLANISHI

6.1. Ushbu shartnoma {{endDate}} sanasida avtomatik ravishda yakunlanadi.

7. YAKUNIY SHARTLAR

7.1. Ushbu shartnomada belgilangan bo'lmagan masalalar O'zbekiston Respublikasining qonun hujjatlariga ko'ra hal qilinadi.

Xizmat ko'rsatuvchi:
{{ourName}}
STIR: {{ourStir}}
Direktori: {{ourDirector}}
Manzil: {{ourAddress}}
Bank: {{ourBank.bank}}
MFO: {{ourBank.mfo}}
Hisob: {{ourBank.account}}

Xizmat iste'molchi:
{{counterpartyName}}
STIR: {{counterpartyStir}}
Direktori: {{counterpartyDirector}}
Manzil: {{counterpartyAddress}}
Bank: {{counterpartyBank}}
MFO: {{counterpartyMfo}}
Hisob: {{counterpartyAccount}}`,
  },
  {
    id: "service-ru",
    name: "Договор оказания услуг",
    description: "Стандартный договор об оказании услуг",
    language: "ru",
    type: "service",
    content: `ДОГОВОР ОКАЗАНИЯ УСЛУГ

Настоящий договор заключен {{date}} года между {{ourName}} (далее "Исполнитель") и {{counterpartyName}} (далее "Заказчик").

1. ПРЕДМЕТ ДОГОВОРА

1.1. Исполнитель обязуется оказывать услуги по {{description}}.

2. СТОИМОСТЬ И УСЛОВИЯ ОПЛАТЫ

2.1. Заказчик обязуется оплатить услуги в размере {{amount}} {{currency}}.
2.2. Оплата производится {{startDate}}.

3. СРОК ДЕЙСТВИЯ ДОГОВОРА

3.1. Настоящий договор действует с {{startDate}} по {{endDate}}.

4. ОБЯЗАТЕЛЬСТВА СТОРОН

4.1. Исполнитель:
- Оказывает услуги надлежащего качества и в установленные сроки;
- Соблюдает требования законодательства.

4.2. Заказчик:
- Производит оплату в установленные сроки;
- Соблюдает условия использования услуг.

5. ОТВЕТСТВЕННОСТЬ

5.1. Стороны несут ответственность за нарушение условий договора в соответствии с законодательством.

6. РАСТОРЖЕНИЕ ДОГОВОРА

6.1. Договор расторгается {{endDate}} автоматически.

7. ПРОЧИЕ УСЛОВИЯ

7.1. Вопросы, не предусмотренные настоящим договором, регулируются законодательством Республики Узбекистан.

Исполнитель:
{{ourName}}
СТИР: {{ourStir}}
Директор: {{ourDirector}}
Адрес: {{ourAddress}}
Банк: {{ourBank.bank}}
МФО: {{ourBank.mfo}}
Счет: {{ourBank.account}}

Заказчик:
{{counterpartyName}}
СТИР: {{counterpartyStir}}
Директор: {{counterpartyDirector}}
Адрес: {{counterpartyAddress}}
Банк: {{counterpartyBank}}
МФО: {{counterpartyMfo}}
Счет: {{counterpartyAccount}}`,
  },
  {
    id: "sale-uz",
    name: "Sotuvni shartnomasi",
    description: "Tovarlarni sotuvni bo'yicha standart shartnoma",
    language: "uz",
    type: "sale",
    content: `SOTUVNI SHARTNOMASI

Ushbu shartnoma {{date}} yili {{ourName}} (quyida "Sotuvchi" deb ataladi) va {{counterpartyName}} (quyida "Xaridor" deb ataladi) o'rtasida tuzildi.

1. SHARTNOMANING PREDMETI

1.1. Sotuvchi {{description}} tovarlarini sotishga va'da beradi.
1.2. Tovarlarning umumiy miqdori: {{amount}} {{currency}}.

2. NARX VA TO'LOV SHARTLARI

2.1. Tovarlarning narxi: {{amount}} {{currency}}.
2.2. To'lov {{startDate}} sanasida amalga oshiriladi.

3. TOVARLARNI YETKAZIB BERISH

3.1. Tovarlar {{startDate}} sanasida yetkazib beriladi.
3.2. Yetkazib berish manzili: {{counterpartyAddress}}.

4. TOMONLARNING MAJBURIYATLARI

4.1. Sotuvchi:
- Sifatli tovarlarni yetkazib beradi;
- Tovarlarning sertifikatlari bilan taqdim etadi.

4.2. Xaridor:
- To'lovlarni o'z vaqtida amalga oshiradi;
- Tovarlarni qabul qiladi.

5. JAVOBGARLIK

5.1. Tomonlar shartnomaning shartlarini buzganligi uchun javobgarlikka tortiladi.

6. SHARTNOMANING YAKUNLANISHI

6.1. Shartnoma tovarlarni yetkazib berilgandan so'ng yakunlanadi.

Sotuvchi:
{{ourName}}
STIR: {{ourStir}}
Direktori: {{ourDirector}}
Manzil: {{ourAddress}}

Xaridor:
{{counterpartyName}}
STIR: {{counterpartyStir}}
Direktori: {{counterpartyDirector}}
Manzil: {{counterpartyAddress}}`,
  },
  {
    id: "sale-ru",
    name: "Договор купли-продажи",
    description: "Стандартный договор купли-продажи товаров",
    language: "ru",
    type: "sale",
    content: `ДОГОВОР КУПЛИ-ПРОДАЖИ

Настоящий договор заключен {{date}} года между {{ourName}} (далее "Продавец") и {{counterpartyName}} (далее "Покупатель").

1. ПРЕДМЕТ ДОГОВОРА

1.1. Продавец обязуется продать, а Покупатель обязуется купить товары: {{description}}.
1.2. Общая стоимость товаров: {{amount}} {{currency}}.

2. ЦЕНА И УСЛОВИЯ ОПЛАТЫ

2.1. Цена товаров: {{amount}} {{currency}}.
2.2. Оплата производится {{startDate}}.

3. ДОСТАВКА ТОВАРОВ

3.1. Товары доставляются {{startDate}}.
3.2. Место доставки: {{counterpartyAddress}}.

4. ОБЯЗАТЕЛЬСТВА СТОРОН

4.1. Продавец:
- Поставляет товары надлежащего качества;
- Предоставляет сертификаты соответствия.

4.2. Покупатель:
- Производит оплату в установленные сроки;
- Принимает товары.

5. ОТВЕТСТВЕННОСТЬ

5.1. Стороны несут ответственность за нарушение условий договора.

6. РАСТОРЖЕНИЕ ДОГОВОРА

6.1. Договор считается исполненным после доставки товаров.

Продавец:
{{ourName}}
СТИР: {{ourStir}}
Директор: {{ourDirector}}
Адрес: {{ourAddress}}

Покупатель:
{{counterpartyName}}
СТИР: {{counterpartyStir}}
Директор: {{counterpartyDirector}}
Адрес: {{counterpartyAddress}}`,
  },
];

export function getTemplate(
  type: "service" | "sale" | "rent" | "custom",
  language: "uz" | "ru"
): ContractTemplate | undefined {
  return contractTemplates.find((t) => t.type === type && t.language === language);
}

export function interpolateTemplate(
  template: string,
  data: Record<string, any>
): string {
  let result = template;
  Object.entries(data).forEach(([key, value]) => {
    const regex = new RegExp(`{{${key}}}`, "g");
    result = result.replace(regex, String(value || ""));
  });
  return result;
}
