export const translations = {
  uz: {
    // Navigation
    dashboard: "Bosh sahifa",
    contracts: "Shartномалар",
    counterparties: "Kontragentlar",
    settings: "Sozlamalar",
    admin: "Admin paneli",
    logout: "Chiqish",

    // Dashboard
    welcome: "Xush kelibsiz",
    totalContracts: "Jami shartномалар",
    thisMonth: "Bu oyda",
    counterpartiesCount: "Kontragentlar",
    draftContracts: "Qoralama shartномалар",
    monthlyTrends: "Oylik tendensiyalar",
    recentActivity: "So'nggi faoliyat",

    // Contract types
    service: "Xizmat ko'rsatish shartnomasi",
    sale: "Sotuvni shartnomasi",
    rent: "Ijaraga berish shartnomasi",
    custom: "Maxsus shartnoma",

    // Status
    draft: "Qoralama",
    ready: "Tayyor",
    cancelled: "Bekor qilingan",

    // Company types
    legal: "Yuridik shaxs",
    yatt: "YATT",
    individual: "Jismoniy shaxs",

    // Form labels
    contractType: "Shartnoma turi",
    language: "Til",
    contractNumber: "Shartnoma raqami",
    date: "Sana",
    counterpartyType: "Kontragent turi",
    counterpartyName: "Kontragent nomi",
    counterpartyStir: "STIR",
    counterpartyBank: "Bank nomi",
    counterpartyMfo: "MFO",
    counterpartyAccount: "Hisob raqami",
    counterpartyAddress: "Manzil",
    counterpartyDirector: "Direktori",
    amount: "Summa",
    currency: "Valyuta",
    startDate: "Boshlanish sanasi",
    endDate: "Tugash sanasi",
    description: "Tavsifi",

    // Buttons
    create: "Yaratish",
    save: "Saqlash",
    cancel: "Bekor qilish",
    delete: "O'chirish",
    download: "Yuklab olish",
    preview: "Ko'rib chiqish",
    next: "Keyingi",
    back: "Orqaga",

    // Messages
    success: "Muvaffaqiyatli",
    error: "Xato",
    loading: "Yuklanmoqda...",
    noData: "Ma'lumot yo'q",
  },
  ru: {
    // Navigation
    dashboard: "Главная",
    contracts: "Контракты",
    counterparties: "Контрагенты",
    settings: "Настройки",
    admin: "Админ панель",
    logout: "Выход",

    // Dashboard
    welcome: "Добро пожаловать",
    totalContracts: "Всего контрактов",
    thisMonth: "В этом месяце",
    counterpartiesCount: "Контрагенты",
    draftContracts: "Черновики",
    monthlyTrends: "Тренды по месяцам",
    recentActivity: "Последняя активность",

    // Contract types
    service: "Договор оказания услуг",
    sale: "Договор купли-продажи",
    rent: "Договор аренды",
    custom: "Пользовательский договор",

    // Status
    draft: "Черновик",
    ready: "Готово",
    cancelled: "Отменено",

    // Company types
    legal: "Юридическое лицо",
    yatt: "ЯАТТ",
    individual: "Физическое лицо",

    // Form labels
    contractType: "Тип договора",
    language: "Язык",
    contractNumber: "Номер договора",
    date: "Дата",
    counterpartyType: "Тип контрагента",
    counterpartyName: "Имя контрагента",
    counterpartyStir: "СТИР",
    counterpartyBank: "Название банка",
    counterpartyMfo: "МФО",
    counterpartyAccount: "Номер счета",
    counterpartyAddress: "Адрес",
    counterpartyDirector: "Директор",
    amount: "Сумма",
    currency: "Валюта",
    startDate: "Дата начала",
    endDate: "Дата окончания",
    description: "Описание",

    // Buttons
    create: "Создать",
    save: "Сохранить",
    cancel: "Отмена",
    delete: "Удалить",
    download: "Скачать",
    preview: "Просмотр",
    next: "Далее",
    back: "Назад",

    // Messages
    success: "Успешно",
    error: "Ошибка",
    loading: "Загрузка...",
    noData: "Нет данных",
  },
};

export type Language = keyof typeof translations;
export type TranslationKey = keyof typeof translations.uz;

export function t(key: TranslationKey, lang: Language = "uz"): string {
  return translations[lang][key] || key;
}
