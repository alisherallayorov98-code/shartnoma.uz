CREATE TABLE `announcements` (
	`id` int AUTO_INCREMENT NOT NULL,
	`adminId` int NOT NULL,
	`title` text,
	`content` text,
	`language` enum('uz','ru','both') DEFAULT 'both',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `announcements_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `contracts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`contractNumber` varchar(50),
	`type` enum('service','sale','rent','custom') NOT NULL DEFAULT 'service',
	`language` enum('uz','ru') NOT NULL DEFAULT 'uz',
	`status` enum('draft','ready','cancelled') NOT NULL DEFAULT 'draft',
	`date` varchar(20),
	`counterpartyType` enum('legal','yatt','individual') DEFAULT 'legal',
	`counterpartyName` text,
	`counterpartyStir` varchar(20),
	`counterpartyBank` text,
	`counterpartyMfo` varchar(10),
	`counterpartyAccount` varchar(30),
	`counterpartyAddress` text,
	`counterpartyDirector` text,
	`amount` varchar(30),
	`currency` varchar(50),
	`startDate` varchar(20),
	`endDate` varchar(20),
	`description` text,
	`ourName` text,
	`ourStir` varchar(20),
	`ourDirector` text,
	`ourAddress` text,
	`ourBank` json,
	`useSecondaryBank` boolean DEFAULT false,
	`secondaryIndex` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `contracts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `counterparties` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` text NOT NULL,
	`type` enum('legal','yatt','individual') DEFAULT 'legal',
	`stir` varchar(20),
	`bankName` text,
	`mfo` varchar(10),
	`account` varchar(30),
	`address` text,
	`director` text,
	`phone` varchar(20),
	`email` varchar(320),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `counterparties_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `companyName` text;--> statement-breakpoint
ALTER TABLE `users` ADD `stir` varchar(20);--> statement-breakpoint
ALTER TABLE `users` ADD `jshshir` varchar(20);--> statement-breakpoint
ALTER TABLE `users` ADD `bankName` text;--> statement-breakpoint
ALTER TABLE `users` ADD `bankAccount` varchar(30);--> statement-breakpoint
ALTER TABLE `users` ADD `mfo` varchar(10);--> statement-breakpoint
ALTER TABLE `users` ADD `address` text;--> statement-breakpoint
ALTER TABLE `users` ADD `director` text;--> statement-breakpoint
ALTER TABLE `users` ADD `phone` varchar(20);--> statement-breakpoint
ALTER TABLE `users` ADD `language` enum('uz','ru') DEFAULT 'uz' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `plan` enum('free','pro') DEFAULT 'free' NOT NULL;--> statement-breakpoint
ALTER TABLE `users` ADD `contractsUsed` int DEFAULT 0;--> statement-breakpoint
ALTER TABLE `users` ADD `contractsLimit` int DEFAULT 10;--> statement-breakpoint
ALTER TABLE `users` ADD `secondaryRekvizits` json;--> statement-breakpoint
ALTER TABLE `users` ADD `blocked` boolean DEFAULT false;