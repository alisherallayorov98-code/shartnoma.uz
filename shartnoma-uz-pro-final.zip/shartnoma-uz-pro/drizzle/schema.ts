import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, boolean, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  // Contract management specific fields
  companyName: text("companyName"),
  stir: varchar("stir", { length: 20 }),
  jshshir: varchar("jshshir", { length: 20 }),
  bankName: text("bankName"),
  bankAccount: varchar("bankAccount", { length: 30 }),
  mfo: varchar("mfo", { length: 10 }),
  address: text("address"),
  director: text("director"),
  phone: varchar("phone", { length: 20 }),
  language: mysqlEnum("language", ["uz", "ru"]).default("uz").notNull(),
  // Subscription fields
  plan: mysqlEnum("plan", ["free", "pro"]).default("free").notNull(),
  contractsUsed: int("contractsUsed").default(0),
  contractsLimit: int("contractsLimit").default(10),
  // Secondary bank accounts (JSON array)
  secondaryRekvizits: json("secondaryRekvizits"),
  blocked: boolean("blocked").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Contracts table
export const contracts = mysqlTable("contracts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  contractNumber: varchar("contractNumber", { length: 50 }),
  type: mysqlEnum("type", ["service", "sale", "rent", "custom"]).default("service").notNull(),
  language: mysqlEnum("language", ["uz", "ru"]).default("uz").notNull(),
  status: mysqlEnum("status", ["draft", "ready", "cancelled"]).default("draft").notNull(),
  date: varchar("date", { length: 20 }),
  // Counterparty details
  counterpartyType: mysqlEnum("counterpartyType", ["legal", "yatt", "individual"]).default("legal"),
  counterpartyName: text("counterpartyName"),
  counterpartyStir: varchar("counterpartyStir", { length: 20 }),
  counterpartyBank: text("counterpartyBank"),
  counterpartyMfo: varchar("counterpartyMfo", { length: 10 }),
  counterpartyAccount: varchar("counterpartyAccount", { length: 30 }),
  counterpartyAddress: text("counterpartyAddress"),
  counterpartyDirector: text("counterpartyDirector"),
  // Contract terms
  amount: varchar("amount", { length: 30 }),
  currency: varchar("currency", { length: 50 }),
  startDate: varchar("startDate", { length: 20 }),
  endDate: varchar("endDate", { length: 20 }),
  description: text("description"),
  // Our company details (snapshot at creation)
  ourName: text("ourName"),
  ourStir: varchar("ourStir", { length: 20 }),
  ourDirector: text("ourDirector"),
  ourAddress: text("ourAddress"),
  ourBank: json("ourBank"),
  useSecondaryBank: boolean("useSecondaryBank").default(false),
  secondaryIndex: int("secondaryIndex").default(0),
  // Metadata
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Contract = typeof contracts.$inferSelect;
export type InsertContract = typeof contracts.$inferInsert;

// Counterparties table
export const counterparties = mysqlTable("counterparties", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: text("name").notNull(),
  type: mysqlEnum("type", ["legal", "yatt", "individual"]).default("legal"),
  stir: varchar("stir", { length: 20 }),
  bankName: text("bankName"),
  mfo: varchar("mfo", { length: 10 }),
  account: varchar("account", { length: 30 }),
  address: text("address"),
  director: text("director"),
  phone: varchar("phone", { length: 20 }),
  email: varchar("email", { length: 320 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Counterparty = typeof counterparties.$inferSelect;
export type InsertCounterparty = typeof counterparties.$inferInsert;

// System announcements/news
export const announcements = mysqlTable("announcements", {
  id: int("id").autoincrement().primaryKey(),
  adminId: int("adminId").notNull(),
  title: text("title"),
  content: text("content"),
  language: mysqlEnum("language", ["uz", "ru", "both"]).default("both"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Announcement = typeof announcements.$inferSelect;
export type InsertAnnouncement = typeof announcements.$inferInsert;