import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext; } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("contracts router", () => {
  it("should list contracts for authenticated user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.contracts.list({ limit: 10 });

    expect(Array.isArray(result)).toBe(true);
  });
});

describe("counterparties router", () => {
  it("should list counterparties for authenticated user", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.counterparties.list({ limit: 10 });

    expect(Array.isArray(result)).toBe(true);
  });
});

describe("announcements router", () => {
  it("should get latest announcements", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.announcements.latest({ limit: 5 });

    expect(Array.isArray(result)).toBe(true);
  });
});

describe("profile router", () => {
  it("should get user profile", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.profile.me();

    expect(result).toBeDefined();
    expect(result?.id).toBe(1);
    expect(result?.email).toBeDefined();
  });
});
