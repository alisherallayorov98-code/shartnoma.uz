import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { 
  getUserContracts, 
  createContract, 
  updateContract, 
  getContractById,
  getUserCounterparties,
  createCounterparty,
  getLatestAnnouncements,
  getUserById
} from "../db";

export const contractsRouter = router({
  // Get user's contracts
  list: protectedProcedure
    .input(z.object({ limit: z.number().default(20) }).optional())
    .query(async ({ ctx, input }) => {
      return getUserContracts(ctx.user.id, input?.limit || 20);
    }),

  // Get single contract
  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const contract = await getContractById(input.id);
      if (!contract || contract.userId !== ctx.user.id) {
        throw new Error("Contract not found or unauthorized");
      }
      return contract;
    }),

  // Create new contract
  create: protectedProcedure
    .input(z.object({
      type: z.enum(["service", "sale", "rent", "custom"]),
      language: z.enum(["uz", "ru"]),
      contractNumber: z.string().optional(),
      date: z.string(),
      counterpartyType: z.enum(["legal", "yatt", "individual"]),
      counterpartyName: z.string(),
      counterpartyStir: z.string().optional(),
      counterpartyBank: z.string().optional(),
      counterpartyMfo: z.string().optional(),
      counterpartyAccount: z.string().optional(),
      counterpartyAddress: z.string().optional(),
      counterpartyDirector: z.string().optional(),
      amount: z.string().optional(),
      currency: z.string().optional(),
      startDate: z.string().optional(),
      endDate: z.string().optional(),
      description: z.string().optional(),
      useSecondaryBank: z.boolean().default(false),
      secondaryIndex: z.number().default(0),
    }))
    .mutation(async ({ ctx, input }) => {
      const user = await getUserById(ctx.user.id);
      if (!user) throw new Error("User not found");

      // Check plan limits
      if (user.plan === "free" && (user.contractsUsed || 0) >= (user.contractsLimit || 10)) {
        throw new Error("Free plan limit reached");
      }

      const ourBank = input.useSecondaryBank
        ? (user.secondaryRekvizits as any)?.[input.secondaryIndex]
        : { account: user.bankAccount, bank: user.bankName, mfo: user.mfo };

      await createContract({
        userId: ctx.user.id,
        type: input.type,
        language: input.language,
        contractNumber: input.contractNumber,
        date: input.date,
        counterpartyType: input.counterpartyType,
        counterpartyName: input.counterpartyName,
        counterpartyStir: input.counterpartyStir,
        counterpartyBank: input.counterpartyBank,
        counterpartyMfo: input.counterpartyMfo,
        counterpartyAccount: input.counterpartyAccount,
        counterpartyAddress: input.counterpartyAddress,
        counterpartyDirector: input.counterpartyDirector,
        amount: input.amount,
        currency: input.currency,
        startDate: input.startDate,
        endDate: input.endDate,
        description: input.description,
        ourName: user.companyName || user.name,
        ourStir: user.stir || user.jshshir,
        ourDirector: user.director || user.name,
        ourAddress: user.address,
        ourBank: ourBank as any,
        useSecondaryBank: input.useSecondaryBank,
        secondaryIndex: input.secondaryIndex,
        status: "draft",
      } as any);

      return { success: true };
    }),

  // Update contract
  update: protectedProcedure
    .input(z.object({
      id: z.number(),
      data: z.record(z.string(), z.any()),
    }))
    .mutation(async ({ ctx, input }) => {
      const contract = await getContractById(input.id);
      if (!contract || contract.userId !== ctx.user.id) {
        throw new Error("Contract not found or unauthorized");
      }

      await updateContract(input.id, input.data as any);
      return { success: true };
    }),

  // Finalize contract (mark as ready)
  finalize: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const contract = await getContractById(input.id);
      if (!contract || contract.userId !== ctx.user.id) {
        throw new Error("Contract not found or unauthorized");
      }

      await updateContract(input.id, { status: "ready" } as any);
      return { success: true };
    }),
});

export const counterpartiesRouter = router({
  // Get user's counterparties
  list: protectedProcedure.query(async ({ ctx }) => {
    return getUserCounterparties(ctx.user.id);
  }),

  // Create counterparty
  create: protectedProcedure
    .input(z.object({
      name: z.string(),
      type: z.enum(["legal", "yatt", "individual"]),
      stir: z.string().optional(),
      bankName: z.string().optional(),
      mfo: z.string().optional(),
      account: z.string().optional(),
      address: z.string().optional(),
      director: z.string().optional(),
      phone: z.string().optional(),
      email: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      await createCounterparty({
        userId: ctx.user.id,
        ...input,
      } as any);
      return { success: true };
    }),
});

export const announcementsRouter = router({
  // Get latest announcements
  latest: protectedProcedure
    .input(z.object({ limit: z.number().default(5) }).optional())
    .query(async ({ input }) => {
      return getLatestAnnouncements(input?.limit || 5);
    }),
});

export const profileRouter = router({
  // Get user profile
  me: protectedProcedure.query(async ({ ctx }) => {
    return getUserById(ctx.user.id);
  }),
});
